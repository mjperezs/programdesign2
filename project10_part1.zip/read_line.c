#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define EMAIL_LEN 100
#define NAME_LEN 30



//reads the input line
int read_line(char str[], int n)
{
  int ch, i = 0;


  //skips white spaces
  while (isspace(ch = getchar()))
    ;

  //reads the characters until new line or max length 
  str[i++] = ch;
  while ((ch = getchar()) != '\n') {
    if (i < n)
      str[i++] = ch;
    
   }
   str[i] = '\0';
   return i;
}
