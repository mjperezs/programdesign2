#ifndef READ_LINE_H
#define READ_LINE_H

// Function prototype for read_line function
int read_line(char str[], int n);

#endif // READ_LINE_H