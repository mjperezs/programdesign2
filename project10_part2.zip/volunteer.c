
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define EMAIL_LEN 100
#define NAME_LEN 30

//declare a structure for volunteer data
struct volunteer
{
	char first[NAME_LEN+1];
	char last[NAME_LEN+1];
	char email[EMAIL_LEN+1];
	int grade_level;
	struct volunteer *next;
};

//declares functions
struct volunteer *add_to_list(struct volunteer *list);
struct volunteer *delete_from_list(struct volunteer *list);
void search_list(struct volunteer *list);
void print_list(struct volunteer *list);
void clear_list(struct volunteer *list);
int read_line(char str[], int n);

/**********************************************************
 * main: Prompts the user to enter an operation code,     *
 *       then calls a function to perform the requested   *
 *       action. Repeats until the user enters the        *
 *       command 'q'. Prints an error message if the user *
 *       enters an illegal code.                          *
 **********************************************************/


//function that adds a new volunteer to list
struct volunteer *add_to_list(struct volunteer *list)
{
  //creates memory for new volunteer
  struct volunteer *new_volunteer = malloc(sizeof(struct volunteer));

  //prompts the user for volunteer's last name
  printf("Enter last name: ");
  read_line(new_volunteer->last, NAME_LEN);

  //prompts the user for volunteer's first name 
  printf("Enter first name: ");
  read_line(new_volunteer->first, NAME_LEN);

  //prompts the user for volunteer's email 
  printf("Enter email address: ");
  read_line(new_volunteer->email, EMAIL_LEN);

  //prompts the user for volunteer's grade level
  printf("Enter grade level: ");
  scanf("%d", &new_volunteer->grade_level);
  
   
  //verifies if the volunteer already exists

  struct volunteer *curr = list;

  while (curr != NULL) 
  {
    if ((strcmp(curr->email, new_volunteer->email) == 0) && (strcmp(curr->last, new_volunteer->last) == 0)) 
    {
      printf("volunteer already exists.\n");
      free(new_volunteer);
      
      return list; 
    }

    curr = curr->next;
  
  }

  //add the new volunteer to the end of the list
  new_volunteer->next = NULL;

  if (list == NULL) 
  {
    return new_volunteer;
  }
  else
  {
    struct volunteer *curr = list;

    while (curr->next != NULL) 
    {
      curr = curr->next; 
    }
    curr->next = new_volunteer;
    return list;
  }
 
}

// Function to remove a volunteer from the list
//function to delete a volunteer from the list
struct volunteer *delete_from_list(struct volunteer *list)
{
    //prompt the user for volunteer's data
    char last[NAME_LEN+1];
    char first[NAME_LEN+1];
    char email[EMAIL_LEN+1];
    int grade;

    printf("Enter last name: ");
    read_line(last, NAME_LEN);

    printf("Enter first name: ");
    read_line(first, NAME_LEN);

    printf("Enter email address: ");
    read_line(email, EMAIL_LEN);

    printf("Enter grade level: ");
    scanf("%d", &grade);

    //declare variables
    struct volunteer *prev = NULL;
    struct volunteer *curr = list;

    //flag to track if volunteer is found
    int found = 0;

    //traverse the list
    while (curr != NULL)
    {
        //check if volunteer matches
        if (strcmp(curr->last, last) == 0 &&
            strcmp(curr->first, first) == 0 &&
            strcmp(curr->email, email) == 0 &&
            curr->grade_level == grade)
        {
            found = 1;

            //if found volunteer is the first node
            if (prev == NULL)
            {
                list = curr->next;
                free(curr);
                return list;
            }
            else
            {
                prev->next = curr->next;
                free(curr);
                return list;
            }
        }

        //move to next node
        prev = curr;
        curr = curr->next;
    }

    //if volunteer not found
    if (!found)
        printf("volunteer does not exist.\n");

    return list;
}


//function to search for volunteers by grade level
void search_list(struct volunteer *list)
{

  //declare variable
  int grade;

  //prompts the user to enter grade level to be searched
  printf("Enter grade level: ");
  //stores the grade level
  scanf("%d", &grade);


  //declares flag if volunteers matched
  int found = 0;

  //looks for the matched volunteers and prints them
  struct volunteer *curr = list;
  
  while (curr != NULL) 
  {
    if (curr->grade_level == grade) 
    {
      printf("%-12s%-12s%-30s\n", curr->last, curr->first, curr->email, curr->grade_level);
      found = 1;
    }
      curr = curr->next;
    }
    if (!found) 
    {
      printf("not found\n");
    }
}

//prints the volunteer list
void print_list(struct volunteer *list)
{
  struct volunteer *curr = list;
  
  //traverses the list and prints volunteers's data
  while (curr != NULL) 
  {
    printf("%-12s%-12s%-30s%5d\n", curr->last, curr->first, curr->email, curr->grade_level);
    curr = curr->next;
  }


}

//clears the list memory
void clear_list(struct volunteer *list)
{
  struct volunteer *curr = list;
  
  //traverses the list and frees memory of each volunteer
  while (curr != NULL) 
  {
    struct volunteer *temp = curr;
    curr = curr->next;
    free(temp);
  }

}